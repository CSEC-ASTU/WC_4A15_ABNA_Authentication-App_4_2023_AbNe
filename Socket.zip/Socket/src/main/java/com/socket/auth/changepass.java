package com.socket.auth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class changepass
 */
public class changepass extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	String psd = request.getParameter("password");
	String cpsd = request.getParameter("cpassword");
	String email = request.getParameter("email");
	RequestDispatcher Dispatcher =null;
	if(psd == cpsd) {

		
		Dispatcher = request.getRequestDispatcher("login.jsp");
			request.setAttribute("status", "password updated");
			Dispatcher.forward(request, response);
			
	}	
	
	
	else {
		Dispatcher = request.getRequestDispatcher("changepass.jsp");
		request.setAttribute("status", "Mismatch");
		Dispatcher.forward(request, response);

	}
	}
}
