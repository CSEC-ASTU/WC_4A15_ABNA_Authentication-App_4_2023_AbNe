package com.socket.auth;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;





import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.*;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/register")
public class Register extends HttpServlet {	
public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException{
	PrintWriter out = res.getWriter();
	String uname = req.getParameter("uname");
	String pwd = req.getParameter("pwd");
	String cpwd = req.getParameter("cpwd");
	String email = req.getParameter("email");
	String Phone = req.getParameter("contact");
	HttpSession ss = req.getSession();
	RequestDispatcher Dispatcher = null;
	
	
	//Hash The Password
	String PassToHash = pwd;
	String Hashed = null;
	try {
		
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(PassToHash.getBytes());
		
		byte[] bytes= md.digest();
		
		StringBuilder sb = new StringBuilder();
		for(int i=0; i < bytes.length; i++) {
			sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			Hashed = sb.toString();
		}
		
		
		
		
		
		
	}catch(NoSuchAlgorithmException e) {
		e.printStackTrace();
	}
	
	
	
	
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ChatX", "root","abdu");
	String sql = "insert into Chatting values (?,?,?,?)";
	PreparedStatement pst = con.prepareStatement(sql);
		pst.setString(1, uname);
		pst.setString(2, Hashed);
		pst.setString(3, email);
		pst.setString(4, Phone);
		int rs = pst.executeUpdate();
		pst.close();
	Dispatcher = req.getRequestDispatcher("login.jsp");
	Dispatcher.forward(req, res);
	
	
	}catch(Exception e){
		e.printStackTrace();
	}
	}

}
