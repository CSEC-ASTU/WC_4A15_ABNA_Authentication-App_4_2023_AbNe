package com.socket;
import java.io.*;
import java.sql.*;
public class DBconnection {
public		void Load() throws Exception {
	
		Class.forName("com.mysql.cj.jdbc.Driver");
		


}}