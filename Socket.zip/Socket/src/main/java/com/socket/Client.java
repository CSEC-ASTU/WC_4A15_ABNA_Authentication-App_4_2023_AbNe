package com.socket;
import java.io.*;
import java.net.*;
public class Client {

	public static void main(String args[]) {
		try {
			Socket client = new Socket("localhost", 3333);

			DataInputStream dis = new DataInputStream(client.getInputStream());
			DataOutputStream dos = new DataOutputStream(client.getOutputStream());
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String str1="", str2="";
			while(!str1.equals("stop")){
			str2 = br.readLine();
			dos.writeUTF(str2);
			str1 = dis.readUTF();
			System.out.println("from client"+ str1);
				
			}
			
			client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
