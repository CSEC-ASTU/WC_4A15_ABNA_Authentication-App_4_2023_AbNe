package com.socket;

public @interface WebServlet {

}
